CREATE DATABASE Employee_Management;
USE Employee_Management;

-- Table 1: Job Department
CREATE TABLE JobDepartment (
    Job_ID INT PRIMARY KEY,
    jobdept VARCHAR(50),
    name VARCHAR(100),
    description TEXT,
    salaryrange VARCHAR(50)
);
select * from JobDepartment;

-- Table 2: Salary/Bonus
CREATE TABLE SalaryBonus (
    salary_ID INT PRIMARY KEY,
    Job_ID INT,
    amount DECIMAL(10,2),
    annual DECIMAL(10,2),
    bonus DECIMAL(10,2),
    CONSTRAINT fk_salary_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(Job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);
select * from SalaryBonus;

-- Table 3: Employee
CREATE TABLE Employee (
    emp_ID INT PRIMARY KEY,
    firstname VARCHAR(50),
    lastname VARCHAR(50),
    gender VARCHAR(10),
    age INT,
    contact_add VARCHAR(100),
    emp_email VARCHAR(100) UNIQUE,
    emp_pass VARCHAR(50),
    Job_ID INT,
    CONSTRAINT fk_employee_job FOREIGN KEY (Job_ID)
        REFERENCES JobDepartment(Job_ID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);
select * from employee;

-- Table 4: Qualification
CREATE TABLE Qualification (
    QualID INT PRIMARY KEY,
    Emp_ID INT,
    Position VARCHAR(50),
    Requirements VARCHAR(255),
    Date_In DATE,
    CONSTRAINT fk_qualification_emp FOREIGN KEY (Emp_ID)
        REFERENCES Employee(emp_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
select * from Qualification;

-- Table 5: Leaves
CREATE TABLE Leaves (
    leave_ID INT PRIMARY KEY,
    emp_ID INT,
    date DATE,
    reason TEXT,
    CONSTRAINT fk_leave_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);

select * from Leaves ;

-- Table 6: Payroll
CREATE TABLE Payroll (
    payroll_ID INT PRIMARY KEY,
    emp_ID INT,
    job_ID INT,
    salary_ID INT,
    leave_ID INT,
    date DATE,
    report TEXT,
    total_amount DECIMAL(10,2),
    CONSTRAINT fk_payroll_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_salary FOREIGN KEY (salary_ID) REFERENCES SalaryBonus(salary_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_leave FOREIGN KEY (leave_ID) REFERENCES Leaves(leave_ID)
        ON DELETE SET NULL ON UPDATE CASCADE
);


select * from JobDepartment;
select * from SalaryBonus;
select * from Employee;
select * from Qualification;
select * from Leaves;
select * from Payroll;



-- Analysis Questions

-- 1. EMPLOYEE INSIGHTS 

-- How many unique employees are currently in the system?
SELECT COUNT(DISTINCT emp_ID) AS Total_Employees
FROM Employee;

-- Which departments have the highest number of employees?
SELECT jd.jobdept AS Department, COUNT(e.emp_ID) AS Employee_Count
FROM Employee e
JOIN JobDepartment jd ON e.Job_ID = jd.Job_ID
GROUP BY jd.jobdept
ORDER BY Employee_Count DESC;

-- What is the average salary per department? 
SELECT jd.jobdept AS Department, AVG(sb.amount) AS Avg_Salary
FROM SalaryBonus sb
JOIN JobDepartment jd ON sb.Job_ID = jd.Job_ID
GROUP BY jd.jobdept;

-- Who are the top 5 highest-paid employees?
SELECT e.firstname, e.lastname, sb.amount AS Salary
FROM Employee e
JOIN SalaryBonus sb ON e.Job_ID = sb.Job_ID
ORDER BY sb.amount DESC
LIMIT 5;

-- What is the total salary expenditure across the company?
SELECT SUM(sb.annual+sb.bonus) as Total_Salary_Expenditure FROM SalaryBonus sb;

-- 2. JOB ROLE AND DEPARTMENT ANALYSIS

-- How many different job roles exist in each department?
SELECT jobdept AS Department, COUNT(name) AS Total_Roles
FROM JobDepartment
GROUP BY jobdept;

-- What is the average salary range per department? 
SELECT jobdept,
AVG(sb.amount) AS avg_salary_per_department
FROM jobdepartment jd
JOIN salarybonus sb
ON jd.job_id=sb.job_id
GROUP BY jobdept;

-- Which job roles offer the highest salary? 
SELECT jd.name AS JobRole, sb.amount AS Salary
FROM SalaryBonus sb
JOIN JobDepartment jd ON sb.Job_ID = jd.Job_ID
ORDER BY sb.amount DESC
LIMIT 5;

--  Which departments have the highest total salary allocation? 
SELECT jd.jobdept AS Department, SUM(sb.annual+sb.bonus) AS Total_Salary
FROM SalaryBonus sb
JOIN JobDepartment jd ON sb.Job_ID = jd.Job_ID
GROUP BY jd.jobdept
ORDER BY Total_Salary DESC
LIMIT 5;

-- 3. QUALIFICATION AND SKILLS ANALYSIS 
-- How many employees have at least one qualification listed? 
SELECT COUNT(DISTINCT Emp_ID) AS Employees_Atleat_One_Qualifications
FROM Qualification;


-- Which positions require the most qualifications? 
SELECT Position,COUNT(*) AS Qualification_Count
FROM Qualification
GROUP BY position
ORDER BY Qualification_Count;

--  Which employees have the highest number of qualifications? 
SELECT 
	e.emp_id AS Emp_ID,
	e.firstname AS FirstName,
    e.lastname AS LastName,
	COUNT(QualID) AS No_of_Qualifications
FROM 
	employee AS e 
INNER JOIN 
	qualification AS q
ON 
	e.emp_ID=q.Emp_ID
GROUP BY 
	e.emp_ID
ORDER BY 
	No_of_Qualifications DESC
LIMIT 5;


-- 4. LEAVE AND ABSENCE PATTERNS 

-- Which year had the most employees taking leaves? 
SELECT YEAR(date) AS Year,COUNT(*) AS Total_Leaves
FROM Leaves
GROUP BY YEAR(date)
ORDER BY Total_Leaves;

-- What is the average number of leave days taken by its employees per department? 
SELECT 
    j.jobdept Department,
    ROUND(COUNT(l.leave_id) / COUNT(e.emp_ID), 0) AS AVG_no_of_Leaves
FROM
    jobdepartment j
        INNER JOIN
    employee e
        INNER JOIN
    Leaves l ON e.emp_ID = l.emp_ID
        AND j.job_ID = e.job_ID
GROUP BY Department;

-- Which employees have taken the most leaves? 
SELECT 
    e.emp_ID Emp_ID,
    e.firstname FirstName,
    e.lastname LastName,
    COUNT(l.leave_ID) No_of_Leaves
FROM
    leaves l
        INNER JOIN
    employee e ON e.emp_ID = l.emp_ID
GROUP BY e.emp_ID
ORDER BY No_of_Leaves DESC
LIMIT 5;


-- What is the total number of leave days taken company-wide? 
SELECT COUNT(*) AS Total_Leaves_days
FROM Leaves;

-- How do leave days correlate with payroll amounts? 
SELECT 
    p.Leave_id,
    COUNT(l.date) AS leave_days,
    SUM(p.total_amount) AS total_payroll
FROM
    Payroll AS p
        INNER JOIN
    leaves AS l ON p.leave_ID = l.leave_ID
GROUP BY p.leave_ID;


-- 5. PAYROLL AND COMPENSATION ANALYSIS 

-- What is the total monthly payroll processed?
SELECT
	MONTH(date) AS Month,
    SUM(total_amount) AS Total_Payroll
FROM 
	payroll
GROUP BY 
	Month
ORDER BY 
	Total_Payroll;

-- What is the average bonus given per department? 
SELECT jd.jobdept, AVG(sb.bonus) AS Avg_Bonus
FROM SalaryBonus sb
JOIN JobDepartment jd ON sb.Job_ID = jd.Job_ID
GROUP BY jd.jobdept;	

-- Which department receives the highest total bonuses? 
SELECT 
	j.jobdept AS Department,
    SUM(s.bonus) AS Total_Bonus
FROM 
	jobdepartment AS j 
INNER JOIN
	salarybonus AS s 
ON
	j.Job_ID=s.Job_ID
GROUP BY 
	Department
ORDER BY 
	Total_Bonus DESC
LIMIT 1;

-- What is the average value of total_amount after considering leave deductions?
SELECT AVG(total_amount) AS Avg_Pay_After_Deduction
FROM payroll;




